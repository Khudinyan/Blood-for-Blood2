package com.example.bloodforblood;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import com.example.bloodforblood.databinding.ActivityMainBinding;
import com.google.android.material.bottomnavigation.BottomNavigationView;



public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Inflate the layout using the binding object
        ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());

        // Set the content view to the root view of the binding
        setContentView(binding.getRoot());

        // Access the BottomNavigationView using the binding
        BottomNavigationView navView = binding.navView;
    }
}
