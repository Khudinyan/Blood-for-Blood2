public class Player {
    private int x,y;
    private int speed=10;
    public Player(int startX,int startY){
        this.x=startX;
        this.y=startY;
    }
    public void moveLeft(){
        x -=speed;
    }
    public void moveRight(){
        x +=speed;
    }
    public void moveUp(){
        y-=speed;
    }
    public void moveDown(){
        y+=speed;
    }
    public int getX() {
        return x;
    }
    public int getY(){
        return y;
    }
}
